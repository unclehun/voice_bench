import Foundation
import VoiceBenchCore

struct Expected: Decodable { let substitutions: Int; let deletions: Int; let insertions: Int; let reference_count: Int; let hypothesis_count: Int; let rate: Double }
struct Item: Decodable { let id: String; let reference: String; let hypothesis: String; let expected: Expected }
let input = URL(fileURLWithPath: CommandLine.arguments[1])
let items = try JSONDecoder().decode([Item].self, from: Data(contentsOf: input))
for item in items {
    let actual = Evaluation.cer(reference: item.reference, hypothesis: item.hypothesis)
    let expected = item.expected
    guard actual.substitutions == expected.substitutions, actual.deletions == expected.deletions,
          actual.insertions == expected.insertions, actual.referenceCount == expected.reference_count,
          actual.hypothesisCount == expected.hypothesis_count, abs((actual.rate ?? -1) - expected.rate) < 1e-12 else {
        throw BenchError("Independent CER mismatch for run \(item.id)")
    }
}
print("PASS: all \(items.count) primary CER results independently match the App's actual Swift Evaluation.cer implementation (S/D/I, character counts and rate).")
