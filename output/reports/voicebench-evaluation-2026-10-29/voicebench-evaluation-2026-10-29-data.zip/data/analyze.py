"""Reproducible, offline evaluation of the read-only phone snapshot against user supplied text."""
import csv
import hashlib
import json
import random
import re
import statistics
import unicodedata
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ENGINES = {
    'sensevoice_small_int8': 'SenseVoice',
    'apple_speechtranscriber': 'Apple Speech',
    'qwen3_asr_0_6b_int8': 'Qwen3-ASR',
    'fun_asr_mlt_nano_int8': 'Fun-ASR-MLT-Nano',
}

def normalize(text):
    return ''.join(chr(ord(c) + 32) if 'A' <= c <= 'Z' else c for c in text
                   if not c.isspace() and not unicodedata.category(c).startswith('P'))

def alignment(a, b):
    # Levenshtein with the same substitute > delete > insert tie order as Evaluation.swift.
    rows = [list(range(len(b) + 1))]
    for i, x in enumerate(a, 1):
        row = [i]
        previous = rows[-1]
        for j, y in enumerate(b, 1):
            row.append(previous[j-1] if x == y else min(previous[j-1]+1, previous[j]+1, row[j-1]+1))
        rows.append(row)
    i, j = len(a), len(b)
    ops = []
    while i or j:
        if i and j and a[i-1] == b[j-1]:
            ops.append(('equal', a[i-1], b[j-1])); i -= 1; j -= 1
        elif i and j and rows[i][j] == rows[i-1][j-1]+1:
            ops.append(('substitute', a[i-1], b[j-1])); i -= 1; j -= 1
        elif i and rows[i][j] == rows[i-1][j]+1:
            ops.append(('delete', a[i-1], '')); i -= 1
        else:
            ops.append(('insert', '', b[j-1])); j -= 1
    ops.reverse()
    counts = Counter(op[0] for op in ops)
    return {'substitutions': counts['substitute'], 'deletions': counts['delete'],
            'insertions': counts['insert'], 'errors': rows[-1][-1],
            'reference_count': len(a), 'hypothesis_count': len(b),
            'rate': rows[-1][-1]/len(a) if a else None}, ops

def is_han(c):
    return '\u3400' <= c <= '\u9fff' or '\U00020000' <= c <= '\U0002fa1f'

def english_words(text):
    return re.findall(r"[a-z]+(?:['’][a-z]+)*", text.lower())

def mixed_tokens(text):
    # Tokenize before dropping punctuation, so "talking,but" remains two English words.
    return [token for token in re.findall(r'[a-z]+|\d+|[^\s]', text.lower())
            if not all(unicodedata.category(c).startswith('P') for c in token)]

def chinese_number(n):
    n = int(n)
    if n < 10: return '零一二三四五六七八九'[n]
    if n < 100: return ('' if n//10 == 1 else chinese_number(n//10))+'十'+('' if n%10 == 0 else chinese_number(n%10))
    return str(n)

def equivalent_numbers(text):
    text = re.sub(r'(?<![a-z])fifteen(?![a-z])', '十五', text, flags=re.I)
    text = re.sub(r'(?<![a-z])fifty(?![a-z])', '五十', text, flags=re.I)
    return re.sub(r'(?<![a-z0-9])\d+(?![a-z0-9])', lambda m: chinese_number(m[0]), text, flags=re.I)

def diff_groups(ops):
    groups = []
    for kind, original, revised in ops:
        if groups and groups[-1]['kind'] == kind:
            groups[-1]['reference'] += original
            groups[-1]['hypothesis'] += revised
        else:
            groups.append({'kind': kind, 'reference': original, 'hypothesis': revised})
    return groups

def aggregate(rows):
    output = {}
    for engine in ENGINES:
        subset = [r for r in rows if r['engine'] == engine]
        successful = [r for r in subset if r['status'] == 'completed']
        metrics = {}
        for name in ['cer', 'zh_cer', 'en_wer', 'mer', 'numeric_equivalent_cer']:
            errors = sum(r[name]['errors'] for r in subset)
            reference = sum(r[name]['reference_count'] for r in subset)
            metrics[name] = {'errors': errors, 'reference_count': reference, 'micro_rate': errors/reference,
                'macro_rate': statistics.mean(r[name]['rate'] for r in subset)}
        latency = [r['processing_seconds'] for r in successful]
        total_latency = [r['total_seconds'] for r in successful]
        duration = sum(r['duration_seconds'] for r in successful)
        common = [r for r in successful if r['recording_number'] != 7]
        output[engine] = {'title': ENGINES[engine], 'n': len(subset), 'success': len(successful),
            'metrics': metrics, 'successful_only_cer': sum(r['cer']['errors'] for r in successful)/sum(r['cer']['reference_count'] for r in successful),
            'processing_mean_seconds': statistics.mean(latency), 'processing_median_seconds': statistics.median(latency),
            'processing_min_seconds': min(latency), 'processing_max_seconds': max(latency),
            'initialization_mean_seconds': statistics.mean(r['initialization_seconds'] for r in successful),
            'total_mean_seconds': statistics.mean(total_latency),
            'weighted_rtf': sum(latency)/duration, 'speed_multiple': duration/sum(latency),
            'common_9_cer': sum(r['cer']['errors'] for r in common)/sum(r['cer']['reference_count'] for r in common),
            'common_9_mean_seconds': statistics.mean(r['processing_seconds'] for r in common),
            'median_cer': statistics.median(r['cer']['rate'] for r in subset),
            'max_cer': max(r['cer']['rate'] for r in subset),
            'wins': 0, 'ties_for_best': 0}
    for number in range(1, 11):
        subset = [r for r in rows if r['recording_number'] == number]
        minimum = min(r['cer']['rate'] for r in subset)
        winners = [r for r in subset if r['cer']['rate'] == minimum]
        for r in winners: output[r['engine']]['wins' if len(winners) == 1 else 'ties_for_best'] += 1
    return output

def main():
    references = json.loads((ROOT/'references.json').read_text())['recordings']
    records = [json.loads(p.read_text()) for p in (ROOT/'raw').glob('*.json')]
    records.sort(key=lambda r: int(re.search(r'\d+', r['name'])[0]))
    assert len(records) == len(references) == 10
    manifest = json.loads((ROOT/'acquisition.json').read_text())
    for entry in manifest['files']:
        assert hashlib.sha256((ROOT/entry['local']).read_bytes()).hexdigest() == entry['sha256']
    results, history, corrections, verification = [], [], [], []
    for rec, ref in zip(records, references):
        number = int(re.search(r'\d+', rec['name'])[0]); assert number == ref['number']
        text = '\n'.join(filter(None, [ref['title'], ref['body'], ref['source_note']]))
        latest_batch = rec['runs'][-1].get('batchID')
        for run in rec['runs']:
            history.append({'recording_number': number, 'engine': run['engine'], 'status': run['status'],
                'run_id': run['id'], 'batch_id': run.get('batchID'), 'started_at_apple_epoch_seconds': run.get('startedAt'),
                'app_version': run.get('configuration',{}).get('app_version'), 'error': run.get('error'),
                'raw_text_length': len(run.get('rawText','')), 'is_primary': run.get('batchID') == latest_batch})
        for engine in ENGINES:
            candidates = [r for r in rec['runs'] if r['engine'] == engine and (latest_batch is None or r.get('batchID') == latest_batch)]
            assert candidates, (number, engine)
            run = candidates[-1]
            raw = run.get('rawText', '')
            hypothesis = raw if run['status'] == 'completed' else ''
            cer, ops = alignment(normalize(text), normalize(hypothesis))
            zh, _ = alignment([c for c in normalize(text) if is_han(c)], [c for c in normalize(hypothesis) if is_han(c)])
            english, _ = alignment(english_words(text), english_words(hypothesis))
            mer, _ = alignment(mixed_tokens(text), mixed_tokens(hypothesis))
            numerical, _ = alignment(normalize(equivalent_numbers(text)), normalize(equivalent_numbers(hypothesis)))
            seconds = (run.get('transcriptionMS') or 0)/1000 if run['status'] == 'completed' else None
            init = (run.get('preparationMS') or 0)/1000 if run['status'] == 'completed' else None
            row = {'recording_number': number, 'recording_id': rec['id'], 'recording_title': ref['title'],
                'duration_seconds': rec['duration'], 'audio_sha256': rec['sha256'], 'run_id': run['id'],
                'batch_id': run.get('batchID'), 'engine': engine, 'engine_title': ENGINES[engine], 'status': run['status'],
                'error': run.get('error'), 'reference': text, 'raw_text': raw,
                'model_version': run['modelVersion'], 'configuration': run.get('configuration',{}),
                'language_detection': run.get('languageDetection'), 'segments': run.get('segments',[]),
                'cer': cer, 'zh_cer': zh, 'en_wer': english, 'mer': mer, 'numeric_equivalent_cer': numerical,
                'processing_seconds': seconds, 'initialization_seconds': init,
                'total_seconds': seconds+init if seconds is not None else None,
                'rtf': seconds/rec['duration'] if seconds is not None else None,
                'diff': diff_groups(ops)}
            results.append(row)
            verification.append({'id': run['id'], 'reference': text, 'hypothesis': hypothesis, 'expected': cer})
            for kind in ['correction','deepSeekCorrection']:
                c = run.get(kind) or {}
                if c.get('status') and c['status'] != 'not_requested':
                    valid = c['status'] in ['completed', 'partial'] and c.get('text') is not None
                    applied = c.get('text') if valid else None
                    corrected, _ = alignment(normalize(text), normalize(applied)) if valid else (None, None)
                    corrections.append({'recording_number': number, 'engine': engine, 'provider': kind,
                        'status': c.get('status'), 'model': c.get('model'), 'elapsed_ms': c.get('elapsedMS'),
                        'text_changed': applied != raw if valid else None, 'corrected_text': applied,
                        'corrected_cer': corrected, 'raw_cer': cer['rate'], 'error': c.get('error'),
                        'blocks': c.get('blocks',[])})
    summary = aggregate(results)
    # Paired bootstrap across recording units, preserving each unit's character weight.
    rng = random.Random(20261029)
    bootstrap = {}
    base = 'sensevoice_small_int8'
    by_pair = {(r['recording_number'], r['engine']): r for r in results}
    for engine in ENGINES:
        if engine == base: continue
        deltas = []
        for _ in range(10000):
            sample = [rng.randrange(1,11) for _ in range(10)]
            denominator = sum(by_pair[n,base]['cer']['reference_count'] for n in sample)
            deltas.append(sum(by_pair[n,engine]['cer']['errors']-by_pair[n,base]['cer']['errors'] for n in sample)/denominator)
        deltas.sort()
        bootstrap[engine] = {'difference': summary[engine]['metrics']['cer']['micro_rate']-summary[base]['metrics']['cer']['micro_rate'],
            'lower_95': deltas[250], 'upper_95': deltas[9749], 'resamples': 10000, 'unit': 'recording', 'baseline': base}
    output = {'method': {'normalization': 'unicode-scalars-punctuation-whitespace-latin-case-v1',
        'main_reference': 'all spoken: title + body + source note, per user confirmation',
        'run_selection': 'latest batch per recording; last run per engine within that batch; no historical-success fallback',
        'failure_policy': 'failure counted as empty transcript for end-to-end CER; successful-only metrics separately',
        'en_wer': 'English word sequences only, case-insensitive; punctuation ignored; word boundaries retained',
        'zh_cer': 'Han-only projections; diagnostic, not a replacement for mixed-script CER',
        'numeric_equivalent_cer': 'convert isolated Arabic integers below 100 and English fifteen/fifty to Chinese numbers; all other scoring unchanged'},
        'recordings': len(records), 'total_audio_seconds': sum(r['duration'] for r in records),
        'total_history_runs': len(history), 'summary': summary, 'bootstrap': bootstrap,
        'results': results, 'history': history, 'corrections': corrections}
    (ROOT/'analysis.json').write_text(json.dumps(output, ensure_ascii=False, indent=2))
    (ROOT/'swift-verification-input.json').write_text(json.dumps(verification, ensure_ascii=False))
    fields = ['recording_number','engine_title','status','cer','zh_cer','en_wer','mer','numeric_equivalent_cer',
              'substitutions','deletions','insertions','reference_count','processing_seconds','initialization_seconds','rtf','run_id']
    with (ROOT/'per-recording-metrics.csv').open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields); writer.writeheader()
        for r in results:
            row = {field: r[field] for field in fields if field in r}
            row.update({k:r[k]['rate'] for k in ['cer','zh_cer','en_wer','mer','numeric_equivalent_cer']})
            row.update({k:r['cer'][k] for k in ['substitutions','deletions','insertions','reference_count']})
            writer.writerow(row)
    print(json.dumps({'summary':summary,'bootstrap':bootstrap,'audio_seconds':output['total_audio_seconds'],
        'history_runs':len(history),'correction_count':len(corrections),'correction_statuses':dict(Counter(c['status'] for c in corrections)),
        'correction_changes':sum(c['text_changed'] is True for c in corrections),
        'per_recording':[{'n':r['recording_number'],'engine':r['engine_title'],'status':r['status'],
            'cer':round(r['cer']['rate']*100,2),'en_wer':round(r['en_wer']['rate']*100,2)} for r in results]},ensure_ascii=False,indent=2))

if __name__ == '__main__': main()
