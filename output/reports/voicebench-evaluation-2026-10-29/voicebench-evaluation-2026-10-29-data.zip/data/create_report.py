"""Create a Chinese PDF report, complete offline HTML comparison, Markdown and audit data package."""
import html
import json
import shutil
import statistics
import sys
from collections import Counter
from datetime import datetime, timezone, timedelta
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.graphics.shapes import Drawing
from reportlab.graphics.charts.barcharts import HorizontalBarChart

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
sys.path.insert(0, str(HERE))
from analyze import ENGINES, alignment, normalize

DATA = json.loads((HERE/'analysis.json').read_text())
ACQ = json.loads((HERE/'acquisition.json').read_text())
NOTES = json.loads((HERE/'case_notes.json').read_text())
RESULTS = DATA['results']
SUMMARY = DATA['summary']
E = list(ENGINES)
SHORT = dict(zip(E, ['SenseVoice', 'Apple', 'Qwen3-ASR', 'Fun-ASR']))
OUT = PROJECT/'output/reports/voicebench-evaluation-2026-10-29'
PDF = PROJECT/'output/pdf/voicebench-evaluation-2026-10-29.pdf'
OUT.mkdir(parents=True, exist_ok=True); PDF.parent.mkdir(parents=True, exist_ok=True)

def pct(value, digits=2): return f'{100*value:.{digits}f}%'
def seconds(value): return f'{value:.2f}' if value is not None else '未完成'
def esc(text): return html.escape(str(text), quote=False)
def clean(text):
    return str(text).replace('\u2011', '-').replace('\u2013', '-').replace('\u2014', ' - ')
def rows_for(number): return [r for r in RESULTS if r['recording_number'] == number]

def provider_summary(provider):
    subset = [r for r in DATA['corrections'] if r['provider'] == provider]
    changed_proposals = sum(b.get('proposed') != b['original'] for r in subset for b in r['blocks'])
    return {'count': len(subset), 'changed_proposals': changed_proposals,
            'changed_applied': sum(r['text_changed'] is True for r in subset),
            'mean_seconds': statistics.mean(r['elapsed_ms'] for r in subset)/1000,
            'covered': sorted({r['recording_number'] for r in subset})}

LOCAL = provider_summary('correction')
REMOTE = provider_summary('deepSeekCorrection')

METHOD = [
    '参考稿采用用户本次提供的完整标题、正文及出处；用户明确确认三者均已朗读。“录音 1”等编号标签不计入。共 2,742 个规范化字符，其中汉字 1,744 个、英文 249 个单词。',
    '每条录音仅取最新 batchID 内每个模型的最后一次运行，共 40 条主评结果。不回退挑选旧的成功结果。84 条历史运行单列用于稳定性审计，不混入主排名。',
    '主指标 CER=(替换+删除+插入)/参考字符数。去掉标点和空白，仅折叠 ASCII 英文大小写；保留简繁、同音字及数字形式差异。Python 的 40 条 S/D/I、分母和 CER 均已与 App 实际 Swift Evaluation.cer 独立交叉校验。',
    '端到端主排名将失败按空稿处理，CER=100%；这不同于 App 导出中失败 CER 留空的规则。成功样本 CER、共同成功的 9 条和失败率分别展示，避免隐藏不可用结果。',
    '英文 WER 对提取出的英文词序列计算，保留模型的单词边界；中文 CER 对汉字序列计算。两者是分项诊断。MER 将每个汉字、英文词和独立数字串各计一单位，缓解混合 CER 对英文字符的较大权重。',
    '数字等值 CER 仅把独立阿拉伯整数（小于 100）及 fifteen/fifty 转为相同中文数词。它是格式敏感性分析，不能掩盖 1 与十这类数值变化，也不替代严格 CER。',
    '这里只评价对提供稿件的文字一致性，没有逐段审听原始音频。多模型共现的重复、语序或措辞变化，可能来自实际朗读，不宜全部算成模型幻觉。主评分仍忠实使用用户原文，未事后修改参考稿。',
]

CONCLUSIONS = [
    '默认选择 SenseVoiceSmall INT8：本次 CER 5.80%、英文 WER 5.62%、10/10 完成，平均处理 1.38 秒，含初始化 1.71 秒。它在整体文字保真、英文和速度上最均衡。',
    'Fun-ASR-MLT-Nano 作为按需复核候选：CER 7.26%，中文分项略低于 SenseVoice，MER 7.48% 与 SenseVoice 的 7.43% 接近；但录音 7、9 把英文改成中文，不能直接替换掉保真要求更高的默认输出。',
    'Qwen3-ASR 适合作为人工复核候选：单条中位 CER 5.05%，多条很好；但录音 4 长段改写把 CER 拉到 70.37%。去掉该条后的 9 段 CER 为 5.08%，此分析仅解释异常，不能据此删除失败样本或改排总榜。',
    '当前 Demo 的 Apple Speech 链路暂不作为中英混读默认：端到端 CER 20.31%，9/10 完成，成功样本 CER 仍有 11.11%。应先修复 Whisper 语言误判、整段主要语言路由与缺失语言资源处理，再重新评价系统识别器本体。',
    '金额、时间、否定和罕见专名都应复核。录音 10 中 SenseVoice 把“每年十先令”写成“每年1现例”；不能因为其综合排名第一就允许金额自动入库。优先让第二模型复核有争议的片段，重要数值仍需人工核对。',
]

def table_html(headers, body, extra=''):
    return '<table '+extra+'><thead><tr>'+''.join('<th>'+esc(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+esc(x)+'</td>' for x in row)+'</tr>' for row in body)+'</tbody></table>'

MAIN_HEADERS = ['模型','完成','总 CER','英文 WER','平均处理 / 秒','含初始化 / 秒']
MAIN_ROWS = [[s['title'],f"{s['success']}/10",pct(s['metrics']['cer']['micro_rate']),pct(s['metrics']['en_wer']['micro_rate']),seconds(s['processing_mean_seconds']),seconds(s['total_mean_seconds'])] for s in SUMMARY.values()]
CASE_HEADERS = ['模型','CER','英文 WER','处理 / 秒','汉字 CER','数字等值 CER']
def case_rows(number):
    return [[SHORT[r['engine']],pct(r['cer']['rate']) if r['status']=='completed' else '失败 / 100%',pct(r['en_wer']['rate']),seconds(r['processing_seconds']),pct(r['zh_cer']['rate']),pct(r['numeric_equivalent_cer']['rate'])] for r in rows_for(number)]

def md_table(headers, rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(str(x).replace('|','/').replace('\n',' ') for x in row)+' |' for row in rows])

def build_markdown():
    md = ['# iPhone 十段中英混读实测评比报告','',
        '报告日期：2026-10-29。只读 USB 提取；不修改手机数据、不重跑模型、不读取密钥。','',
        '## 结论','']+['- '+x for x in CONCLUSIONS]+['', '## 总榜', '', md_table(MAIN_HEADERS,MAIN_ROWS), '',
        '总 CER 为按参考字符加权的端到端指标，越低越好；处理时间均值只使用完成的样本，Apple 仅 9 条。', '',
        '## 数据与方法','',f"音频合计 {DATA['total_audio_seconds']:.2f} 秒；手机硬件标识 {ACQ['device']['ProductType']}，iOS {ACQ['device']['ProductVersion']} ({ACQ['device']['BuildVersion']})。读取时 App {ACQ['application']['CFBundleShortVersionString']} / Build {ACQ['application']['CFBundleVersion']}。",'']+['- '+x for x in METHOD]
    md += ['', '## 分项与稳定性','',md_table(['模型','汉字 CER','MER','中位 CER','最大单条 CER','数字等值 CER','平均 RTF'], [[s['title'],pct(s['metrics']['zh_cer']['micro_rate']),pct(s['metrics']['mer']['micro_rate']),pct(s['median_cer']),pct(s['max_cer']),pct(s['metrics']['numeric_equivalent_cer']['micro_rate']),f"{s['weighted_rtf']:.4f}"] for s in SUMMARY.values()]), '',
        'SenseVoice 平均处理速度约为 Qwen 的 6.83 倍、Fun 的 5.76 倍。RTF 包含各自当前 App 处理流程；Apple 包含 Whisper 语言检测处理时间。初始化另报，未计资源下载。固定运行顺序、未随机化，不能据此推断手机电耗或峰值内存。', '',
        '10 条样本的配对 bootstrap（按录音重采样 10,000 次，95%区间）显示，Fun 相对 SenseVoice 的 CER 差值为 +1.46 个百分点，区间约 -1.02 至 +4.34；Qwen 为 +5.07，区间 -1.34 至 +17.10。样本少且受离群值影响，不能宣称总体显著优于所有模型。', '',
        '## Apple 路由与历史失败','',
        '最新一轮录音 7 在 1.82-3.31 秒被误判为芬兰语 fi，在 check_assets 阶段失败，整条无文字。录音 2 的 42.17-47.31 秒被路由到 ja_JP，录音 10 的 45.47-52.14 秒被路由到 ko_KR。录音 4、5、8 的中英内容主要整段使用 zh_CN。这些是现有 Demo 的语言检测 / 资源 / 路由链路问题，不能把整条失败等同于 Apple 识别器本体的能力。', '',
        '历史 84 次运行：SenseVoice 29/29 完成，Apple 21/29 完成、8 次失败，Qwen 16/16 完成，Fun 10/10 完成。历史包含重复重试、不同 App 版本和不均衡样本，不能当成独立随机实验的成功率。', '',
        '## 实际纠错收益','',md_table(['纠错模型','已完成','有修改的候选','最终文字改变','平均耗时 / 秒','覆盖录音'],[['Apple 本地',LOCAL['count'],LOCAL['changed_proposals'],LOCAL['changed_applied'],seconds(LOCAL['mean_seconds']),str(LOCAL['covered'])],['DeepSeek Flash',REMOTE['count'],REMOTE['changed_proposals'],REMOTE['changed_applied'],seconds(REMOTE['mean_seconds']),str(REMOTE['covered'])]]), '',
        '22 条纠错最终采用的文字全部与对应原始转写相同，因此已应用 CER 改善为 0。18 条非原样建议全部被保守检查拒绝；其余 4 条建议原样返回。DeepSeek 只有录音 7、9 下的 7 个引擎结果，覆盖有限，不能混进四套 ASR 的十段总榜。', '',
        '原因可追溯到 Evaluation.correctionCanApply：只要整个发生修改的块包含任一敏感字符（数字、否定、人物关系等），整块修改就被拒绝。此次块基本为整段，因而经常把安全的局部修正也挡住。保护有价值：Apple 对录音 9 的 SenseVoice 候选曾把大段英文翻成中文，候选 CER 从 8.10% 恶化到 50.78%，已被拒绝。DeepSeek 对录音 7 / SenseVoice 的候选则从 4.58% 降至 3.87%，也没有应用。以上候选均为诊断，不是已实现效果。', '',
        '建议下一轮测试更小的句级块，并对“实际变化的跨度”而非整块是否出现敏感字做保护；同时保留数值、否定、语言转换和新增事实检查。当前评比未修改 App 代码，也未重新调用任何纠错服务。', '',
        '## 逐段完整对照','']
    for number in range(1,11):
        row = rows_for(number)[0]; notes=NOTES[str(number)]
        md += [f'### 录音 {number} - {row["recording_title"]}', '', f"时长 {row['duration_seconds']:.2f} 秒。{notes['finding']}", '', '参考原文：','',row['reference'],'',md_table(CASE_HEADERS,case_rows(number)),'']
        for r in rows_for(number):
            md += [f"#### {r['engine_title']}", '',notes['models'][r['engine']],'', '原始识别结果：','',r['raw_text'] if r['raw_text'] else '(无文字：'+(r['error'] or '未完成')+')','']
        md += ['共同偏差 / 复核：'+notes['caution'],'']
    md += ['## 复现和边界','',
        '主样本中录音 2、3、4 的 12 条 ASR 运行来自 App 0.5.3 / Build 11；其余 28 条来自 0.4.1 / Build 10。模型版本一致，本地 Git 中两版的 Engines、Audio 与 LanguageRouting 实现无差异；仍保留版本分层信息，不能把所有历史结果说成一次全新 0.5.3 测试。全部主运行记录热状态为 0，低电量模式 false。', '',
        '数据包保留用户参考稿、USB 原始 metadata 快照、每个源文件 SHA-256、运行 / batch ID、analysis.json、40 行 CSV，以及离线分析脚本。Python 全量 CER 已与 App 的 Swift 实现逐条复核。PDF 为摘要及逐段评析；HTML/本文件包含完整四模型原始转写。', '',
        '本次只有同一手机、同一说话人的十段约十分钟混读，不能外推多人、噪声、方言、实时流、长会议、手机内存或功耗。未以任何模型纠错后的文本冒充原始 ASR，也未用参考稿重新运行模型。','']
    text='\n'.join(md)
    (OUT/'report.md').write_text(text)
    return text

def build_html():
    css='''*{box-sizing:border-box}body{margin:0;background:#f3f5f8;color:#182536;font:15px/1.75 -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif}main{max-width:1180px;margin:auto;padding:36px 24px}header,.card,section{background:white;border:1px solid #dfe5ed;border-radius:16px;padding:25px;margin-bottom:22px}h1{font-size:32px;line-height:1.3;margin:4px 0 16px}h2{font-size:23px}h3{font-size:18px}p{margin:10px 0}.eyebrow{letter-spacing:.08em;color:#4b637b;font-size:12px}.tag{background:#e5f4ed;color:#176843;padding:5px 10px;border-radius:6px}.muted{color:#5a6b7d}.warning{border-left:4px solid #d89924;background:#fff7e8;padding:13px 16px}table{border-collapse:collapse;width:100%;margin:14px 0;font-size:14px}th,td{border-bottom:1px solid #dce3eb;text-align:left;padding:9px 10px;vertical-align:top}th{background:#edf2f7;color:#42556a}.ref,.raw{white-space:pre-wrap;overflow-wrap:anywhere;background:#f6f8fb;border:1px solid #e0e6ee;padding:16px;border-radius:9px}.diff{overflow-wrap:anywhere;line-height:2.05;letter-spacing:.03em}del{background:#ffe2df;color:#a32820;text-decoration:line-through}ins{background:#dcf3e6;color:#12633a;text-decoration:none}.summarybar{display:grid;grid-template-columns:120px 1fr 60px;gap:12px;align-items:center;margin:10px 0}.track{background:#edf1f5;height:18px;border-radius:4px;overflow:hidden}.bar{height:100%;background:#6686ae}.bar.best{background:#2f8b67}details{border:1px solid #d9e2eb;border-radius:10px;margin:12px 0;padding:12px 16px}summary{cursor:pointer;font-weight:600}nav{position:sticky;top:0;z-index:10;background:#ffffffee;border-bottom:1px solid #dbe3ed;padding:10px 20px;display:flex;gap:12px;align-items:center;flex-wrap:wrap}a{color:#235d91}select{padding:7px 12px;border:1px solid #c6d1df;border-radius:7px;background:white}.hidden{display:none}footer{font-size:12px;color:#627183;padding:20px 0}@media(max-width:700px){main{padding:15px 10px}header,section{padding:18px}h1{font-size:25px}table{font-size:12px;display:block;overflow:auto}.summarybar{grid-template-columns:85px 1fr 55px}}@media print{nav{display:none}details{break-inside:avoid}body{background:white}section{border:0;break-before:page}}'''
    parts=['<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>iPhone 十段中英混读实测评比</title><style>'+css+'</style><nav><b>模型筛选</b><select id="engine"><option value="all">全部模型</option>'+''.join(f'<option value="{e}">{esc(ENGINES[e])}</option>' for e in E)+'</select><a href="#overview">总榜</a><a href="#method">方法</a><a href="#correction">纠错</a>'+''.join(f'<a href="#recording-{n}">{n}</a>' for n in range(1,11))+'<a href="per-recording-metrics.csv">下载 CSV</a></nav><main>']
    parts += ['<header id="overview"><div class="eyebrow">VOICEBENCH / IPHONE / 2026-10-29</div><h1>十段中英混读：实测评比与模型选择</h1><p><span class="tag">默认推荐 SenseVoiceSmall INT8</span></p><p class="muted">10 条录音 · 599.41 秒 · 40 条最新批次结果 · 84 条历史运行 · 标题、正文、出处全部计分</p>'+''.join('<p>'+esc(t)+'</p>' for t in CONCLUSIONS)+table_html(MAIN_HEADERS,MAIN_ROWS)]
    for e,s in SUMMARY.items():
        width=s['metrics']['cer']['micro_rate']/0.25*100
        parts += [f'<div class="summarybar"><span>{esc(SHORT[e])}</span><div class="track"><div class="bar {"best" if e==E[0] else ""}" style="width:{width:.3f}%"></div></div><b>{pct(s["metrics"]["cer"]["micro_rate"])}</b></div>']
    parts += ['<p class="muted">条形为总 CER，越低越好。Apple 失败按空稿计分；处理时间只含完成样本。完整方法和限制如下。</p></header>',
        '<section id="method"><h2>评分方法与可比性</h2>'+''.join('<p>'+esc(t)+'</p>' for t in METHOD)+
        '<p class="warning">这是对用户原文的一致性评比，未逐字审听原音。多模型共同出现的自我纠正、重复和措辞变化，可能属于朗读偏差；没有事后改参考稿来提高分数。</p>'+table_html(['模型','汉字 CER','MER','中位 CER','最大 CER','数字等值 CER','平均 RTF'],[[s['title'],pct(s['metrics']['zh_cer']['micro_rate']),pct(s['metrics']['mer']['micro_rate']),pct(s['median_cer']),pct(s['max_cer']),pct(s['metrics']['numeric_equivalent_cer']['micro_rate']),f"{s['weighted_rtf']:.4f}"] for s in SUMMARY.values()])+
        '<p>Fun 的 MER 7.48%，与 SenseVoice 的 7.43% 接近，不能把 1.46 个百分点的总 CER 差异说成所有方面都显著领先。按录音配对 bootstrap 的 Fun-SenseVoice CER 差值 95%区间为 -1.02 至 +4.34 个百分点；Qwen 为 -1.34 至 +17.10。样本仅 10 条，结论限于本次任务。</p></section>',
        '<section id="correction"><h2>Apple 路由与纠错的实际收益</h2><p>Apple 最新录音 7 将标题短片段识别为芬兰语 fi，因 check_assets 阶段不支持而整条失败。录音 2、10 的部分英文分别被路由为日语 ja_JP、韩语 ko_KR；录音 4、5、8 大段中英交替使用 zh_CN。其结果评价的是当前完整链路，不能单独归因为系统模型能力。</p>'+table_html(['纠错模型','记录数','候选改变','实际改变','平均耗时/秒','覆盖录音'],[['Apple 本地',LOCAL['count'],LOCAL['changed_proposals'],LOCAL['changed_applied'],seconds(LOCAL['mean_seconds']),str(LOCAL['covered'])],['DeepSeek Flash',REMOTE['count'],REMOTE['changed_proposals'],REMOTE['changed_applied'],seconds(REMOTE['mean_seconds']),str(REMOTE['covered'])]])+
        '<p>22 条最终纠错全文均与原始转写相同，已应用 CER 改善为 0。18 条改变原文的候选全部被保守检查拒绝，其余 4 条原样返回。当前整块只要含敏感字符，就拒绝该块的所有变化；局部安全修正也会被拦截。DeepSeek 的 7 条记录仅覆盖录音 7 和 9，不能与十段 ASR 总榜混排。</p><p>该保护也挡住了有害候选：Apple 对录音 9 / SenseVoice 的建议曾把大片英文翻成中文，候选 CER 从 8.10% 变为 50.78%；DeepSeek 对录音 7 / SenseVoice 的候选从 4.58% 降为 3.87%，但未应用。建议以后按变化跨度检查敏感事实，并保留语言转换防护；本次未改 App 或重跑模型。</p></section>']
    for number in range(1,11):
        rs=rows_for(number); notes=NOTES[str(number)]
        parts += [f'<section id="recording-{number}"><div class="eyebrow">RECORDING {number:02d} / {rs[0]["duration_seconds"]:.2f} SECONDS</div><h2>{esc(rs[0]["recording_title"])}</h2><p><b>{esc(notes["finding"])}</b></p><h3>参考原文</h3><div class="ref">{esc(rs[0]["reference"])}</div>'+table_html(CASE_HEADERS,case_rows(number))+f'<p class="warning">{esc(notes["caution"])}</p>']
        for r in rs:
            diff=''.join(esc(g['reference']) if g['kind']=='equal' else ('<del>'+esc(g['reference'])+'</del>' if g['reference'] else '')+('<ins>'+esc(g['hypothesis'])+'</ins>' if g['hypothesis'] else '') for g in r['diff'])
            text=r['raw_text'] or '(无文字：'+(r['error'] or '未完成')+')'
            parts += [f'<details class="model" data-engine="{r["engine"]}"><summary>{esc(r["engine_title"])} · CER {pct(r["cer"]["rate"])} · {seconds(r["processing_seconds"])} 秒</summary><p>{esc(notes["models"][r["engine"]])}</p><h3>原始识别结果</h3><div class="raw">{esc(text)}</div><h3>规范化逐字对齐</h3><p class="muted">去标点/空白、英文小写；红色删除，绿色新增，替换显示一删一增。S={r["cer"]["substitutions"]} / D={r["cer"]["deletions"]} / I={r["cer"]["insertions"]}；参考 {r["cer"]["reference_count"]} 字符。</p><div class="diff">{diff}</div><p class="muted">Run {esc(r["run_id"])} · Batch {esc(r["batch_id"])}</p></details>']
        parts += ['</section>']
    parts += ['<section><h2>审计和复现</h2><p>手机硬件标识 iPhone18,1，iOS 27.2 (24B119)；读取时 App 0.5.3 / Build 11。录音 2、3、4 的 12 条主 ASR 记录来自 0.5.3，其余 28 条来自 0.4.1。模型版本一致，本地 Git 比较两版 Engines / Audio / LanguageRouting 无差异，但仍保留版本信息；它们不是一次全新、随机顺序的 0.5.3 测试。</p><p>只读取 App 的 Records 目录，没有读取密钥设置或修改手机。数据包含原始 JSON、SHA-256 清单、用户参考稿、分析脚本及逐条 CSV。历史重复次数不均衡，不以历史次数冒充随机样本量；没有手机功耗、峰值内存或多人泛化结论。</p></section><footer>离线报告，无外部网络资源。主 CER 已与 App Swift 实现逐条复核。PDF 提供摘要与逐段评析，本页面保留全部原始文本及差异。</footer></main><script>document.getElementById("engine").addEventListener("change",e=>{document.querySelectorAll("details.model").forEach(d=>{d.classList.toggle("hidden",e.target.value!=="all"&&d.dataset.engine!==e.target.value)})});</script></html>']
    (OUT/'report.html').write_text(''.join(parts))

pdfmetrics.registerFont(TTFont('CJK','/System/Library/Fonts/Supplemental/Arial Unicode.ttf'))
pdfmetrics.registerFontFamily('CJK',normal='CJK',bold='CJK',italic='CJK',boldItalic='CJK')
BLUE=colors.HexColor('#18344F'); MUTED=colors.HexColor('#5F7184'); GREEN=colors.HexColor('#287B5A')
STYLES={
    'title':ParagraphStyle('title',fontName='CJK',fontSize=25,leading=35,textColor=BLUE,spaceAfter=15,wordWrap='CJK'),
    'h1':ParagraphStyle('h1',fontName='CJK',fontSize=18,leading=26,textColor=BLUE,spaceAfter=12,wordWrap='CJK'),
    'h2':ParagraphStyle('h2',fontName='CJK',fontSize=12,leading=18,textColor=BLUE,spaceBefore=10,spaceAfter=6,wordWrap='CJK'),
    'body':ParagraphStyle('body',fontName='CJK',fontSize=9.6,leading=15,spaceAfter=7,wordWrap='CJK'),
    'small':ParagraphStyle('small',fontName='CJK',fontSize=8.3,leading=12,textColor=MUTED,spaceAfter=6,wordWrap='CJK'),
    'reference':ParagraphStyle('reference',fontName='CJK',fontSize=8.7,leading=13,spaceAfter=8,wordWrap='CJK',textColor=colors.HexColor('#34495E')),
    'cell':ParagraphStyle('cell',fontName='CJK',fontSize=8.2,leading=12,wordWrap='CJK'),
}
def p(text, style='body'): return Paragraph(esc(clean(text)).replace('\n','<br/>'),STYLES[style])
def table(headers, rows, widths=None, font='cell'):
    values=[[p(x,font) for x in headers]]+[[p(x,font) for x in row] for row in rows]
    t=Table(values,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#EAF0F6')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.7,colors.HexColor('#B4C3D2')),('LINEBELOW',(0,1),(-1,-1),.25,colors.HexColor('#DCE3EB')),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7)]))
    return t

def footer(canvas,doc):
    canvas.saveState(); w,h=A4
    canvas.setStrokeColor(colors.HexColor('#D7E0E9')); canvas.line(36,34,w-36,34)
    canvas.setFont('CJK',8); canvas.setFillColor(MUTED)
    canvas.drawString(36,22,'VoiceBench | iPhone 十段中英混读实测 | 2026-10-29')
    canvas.drawRightString(w-36,22,f'第 {doc.page} 页')
    canvas.restoreState()

def cer_chart():
    drawing=Drawing(520,150)
    chart=HorizontalBarChart(); chart.x=110; chart.y=12; chart.width=350; chart.height=125
    chart.data=[[SUMMARY[e]['metrics']['cer']['micro_rate']*100 for e in E]]
    chart.categoryAxis.categoryNames=[SHORT[e] for e in E]
    chart.categoryAxis.labels.fontName='CJK'; chart.categoryAxis.labels.fontSize=8
    chart.valueAxis.valueMin=0; chart.valueAxis.valueMax=25; chart.valueAxis.valueStep=5
    chart.valueAxis.labels.fontName='CJK'; chart.valueAxis.labels.fontSize=8
    chart.barWidth=12; chart.barLabelFormat='%.2f%%'; chart.barLabels.fontName='CJK'; chart.barLabels.fontSize=8
    chart.barLabels.nudge=7; chart.bars[0].fillColor=colors.HexColor('#6B89AA')
    chart.bars[(0,0)].fillColor=GREEN
    drawing.add(chart); return drawing

def build_pdf():
    story=[p('iPhone 十段中英混读\n实测评比与模型选择','title'),p('2026-10-29  |  10 条录音  |  599.41 秒  |  4 套本地 ASR','small'),
        p('默认推荐：SenseVoiceSmall INT8','h1'),p(CONCLUSIONS[0]),table(MAIN_HEADERS,MAIN_ROWS,[126,43,63,65,94,132]),Spacer(1,8),
        p('总字符错误率 CER（越低越好）','h2'),cer_chart(),
        p('关键结论','h2'),p('SenseVoice 兼顾当前样本的文字保真、英文与低延迟。Fun 可按需复核；Qwen 正常样本表现好，但出现一次长段跨语言改写；Apple 先修语言路由，再评系统识别器。'),
        p('重要限制：这是对用户提供稿件的一致性评比，未逐字审听原音。数值、否定和专名仍需人工复核；录音 10 中 SenseVoice 把“十先令”写成“1现例”。'),
        p('主评只取各录音最新 batch 的四模型结果，不混入旧成功记录。失败按空稿计入端到端 CER；Apple 处理时间均值只含 9 条完成记录。','small'),PageBreak(),
        p('分项、离群值与速度','h1'),table(['模型','汉字 CER','MER','中位 CER','数字等值 CER','平均 RTF'],[[SHORT[e],pct(s['metrics']['zh_cer']['micro_rate']),pct(s['metrics']['mer']['micro_rate']),pct(s['median_cer']),pct(s['metrics']['numeric_equivalent_cer']['micro_rate']),f"{s['weighted_rtf']:.4f}"] for e,s in SUMMARY.items()],[98,75,65,80,113,92]),
        p('每条录音的 CER','h2')]
    heat_rows=[]
    for number in range(1,11):
        rs=rows_for(number)
        heat_rows.append([f'录音 {number}']+[pct(r['cer']['rate']) if r['status']=='completed' else '失败 / 100%' for r in rs])
    heat=table(['录音','SenseVoice','Apple','Qwen3-ASR','Fun-ASR'],heat_rows,[63,115,115,115,115])
    for i in range(1,11):
        rs=rows_for(i); best=min(r['cer']['rate'] for r in rs)
        for j,r in enumerate(rs,1):
            if r['cer']['rate']==best: heat.setStyle(TableStyle([('BACKGROUND',(j,i),(j,i),colors.HexColor('#E6F4EB'))]))
    story += [heat,p('浅绿色为该条最低 CER，可能并列。','small'),p('如何解释分数','h2'),
        p('Fun 的 MER 7.48%，与 SenseVoice 的 7.43% 接近；Fun 汉字 CER 7.51%，SenseVoice 7.68%。CER 按英文的每个字母计数，主排名对英文更敏感，因此不能只看一个分数。'),
        p('Qwen 单条中位 CER 为 5.05%，优于 SenseVoice 的 6.78%；但录音 4 的 70.37% 离群值不能隐藏。若仅做诊断、去掉该条，Qwen 其余 9 条 CER 为 5.08%，SenseVoice 为 5.56%。'),
        p('平均处理时间：SenseVoice 1.38 秒、Apple 2.15 秒（9条）、Qwen 9.43 秒、Fun 7.95 秒。含初始化分别为 1.71、2.42、10.59、9.53 秒。按共同成功的 9 条，SenseVoice / Apple / Qwen / Fun 的 CER 分别为 5.94% / 11.11% / 11.31% / 6.22%。'),
        p('按录音配对 bootstrap 的 Fun-SenseVoice CER 差值 95%区间为 -1.02 至 +4.34 个百分点，Qwen 为 -1.34 至 +17.10。仅 10 条样本，不宜宣称总体显著领先。','small'),PageBreak(),
        p('语言路由与纠错：当前瓶颈','h1'),p('Apple 的链路问题','h2'),
        p('录音 7 的 1.82-3.31 秒标题被 Whisper 判为芬兰语 fi，check_assets 阶段拒绝执行，整条原始转写为空。录音 2 的 42.17-47.31 秒路由为 ja_JP，录音 10 的 45.47-52.14 秒路由为 ko_KR。录音 4、5、8 大段中英交替内容主要使用 zh_CN。'),
        p('因此 Apple 的端到端 CER 20.31% 评价的是当前语言检测、资源检查和识别组合。即使只看成功的 9 条，CER 仍为 11.11%。不能把误路由造成的失败当成系统模型本体的能力结论。'),
        p('历史 84 次运行中，SenseVoice 29/29 完成，Apple 21/29 完成、8 次失败，Qwen 16/16 完成，Fun 10/10 完成。历史包含重复重试且次数不均衡，仅供审计，不代表独立随机样本。'),
        p('实际纠错结果','h2'),table(['纠错模型','完成','候选改变','最终改变','均耗时/秒','覆盖录音'],[['Apple 本地',LOCAL['count'],LOCAL['changed_proposals'],LOCAL['changed_applied'],seconds(LOCAL['mean_seconds']),'6 / 7 / 8 / 9'],['DeepSeek Flash',REMOTE['count'],REMOTE['changed_proposals'],REMOTE['changed_applied'],seconds(REMOTE['mean_seconds']),'7 / 9']],[100,45,77,77,85,139]),
        p('22 条最终采用的全文均未变化，已应用 CER 改善为 0。18 条非原样候选全部被拒绝，其余 4 条原样返回；DeepSeek 的 7 条记录覆盖有限，不能作为四套 ASR 的替代排名。'),
        p('保守检查按整块判断：只要发生修改的整个块包含数字、否定或人物关系等敏感字符，就拒绝整块修改。本次每次基本只有一个较长块，安全的局部修正也会被挡住。'),
        p('保护也挡住了坏建议：Apple 对录音 9 / SenseVoice 的候选曾把大片英文翻成中文，候选 CER 从 8.10% 恶化到 50.78%。DeepSeek 对录音 7 / SenseVoice 的候选从 4.58% 降为 3.87%，但同样没有应用。候选分数不等于实际采用的效果。'),
        p('下一步建议','h2'),p('先对纠错使用句级较小块，并只检查实际变化跨度中的敏感事实；保留数值、否定、语言转换和新增事实检查。Apple 路由应处理短片段误判及不支持语言回退。Qwen / Fun 需对跨语言改写做专项回归。本次报告没有修改 App，也没有重新调用模型。'),PageBreak()]
    for number in range(1,11):
        rs=rows_for(number); row=rs[0]; notes=NOTES[str(number)]
        story += [p(f'录音 {number:02d} | {notes["focus"]}','h1'),p(row['recording_title'],'h2'),
            p(f"时长 {row['duration_seconds']:.2f} 秒。{notes['finding']}"),
            table(CASE_HEADERS,case_rows(number),[100,78,82,82,84,97]),p('参考原文（标题、正文、出处）','h2'),p(row['reference'],'reference'),p('各模型的关键差异','h2')]
        for r in rs:
            story += [p(r['engine_title']+'：'+notes['models'][r['engine']])]
        story += [p('共同偏差 / 复核：'+notes['caution'],'small'),p('四模型完整原始转写与规范化逐字红绿差异，见配套 HTML 的对应录音章节；完整文字同时保存在 Markdown 报告。','small'),PageBreak()]
    story += [p('方法、审计与适用边界','h1')]
    for text in METHOD[:6]: story += [p(text,'small')]
    story += [p('误差计数（最新批次，失败计空稿）','h2'),table(['模型','替换 S','删除 D','插入 I','参考字符'],[[SHORT[e]]+[str(sum(r['cer'][k] for r in RESULTS if r['engine']==e)) for k in ['substitutions','deletions','insertions']]+['2742'] for e in E],[135,95,95,95,103]),
        p('数据来源与版本','h2'),p('2026-10-29 10:11（北京时间）通过只读 USB HouseArrest 提取 10 个 Records JSON。手机硬件标识 iPhone18,1，iOS 27.2 / 24B119；读取时 App 0.5.3 / Build 11。未读取 API Key、未修改手机，也未重跑 ASR 或纠错。','small'),
        p('录音 2、3、4 的 12 条主 ASR 运行来自 0.5.3 / Build 11；其余 28 条来自 0.4.1 / Build 10。模型版本一致，本地 Git 比较两版的 Engines / Audio / LanguageRouting 无差异；但保留此版本分层，不能把所有记录描述成一次全新的 0.5.3 测试。热状态均为 0，低电量模式均为 false。','small'),
        p('原始 JSON、文件 SHA-256、每条运行与 batch ID、参考稿、CSV、分析脚本及 Swift 交叉验证程序都在配套数据包。主 CER 的 40 组 S/D/I、分母与分值已独立复核。','small'),
        p('结论限于同一手机、同一说话人的 10 段约十分钟中英混读。未逐段审听原音，可能有读稿差异；未测多人、噪声、方言、长会议、实时流、手机峰值内存或功耗。','small')]
    doc=SimpleDocTemplate(str(PDF),pagesize=A4,rightMargin=36,leftMargin=36,topMargin=40,bottomMargin=44,
        title='iPhone 十段中英混读实测评比与模型选择',author='VoiceBench evaluation',pageCompression=1)
    doc.build(story,onFirstPage=footer,onLaterPages=footer)

def main():
    build_markdown(); build_html(); build_pdf()
    shutil.copy2(HERE/'per-recording-metrics.csv',OUT/'per-recording-metrics.csv')
    summary={'summary':DATA['summary'],'bootstrap':DATA['bootstrap'],'local_correction':LOCAL,'deepseek_correction':REMOTE,'method':DATA['method']}
    (OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    print(json.dumps({'pdf':str(PDF),'html':str(OUT/'report.html'),'markdown':str(OUT/'report.md'),'csv':str(OUT/'per-recording-metrics.csv')},ensure_ascii=False))

if __name__ == '__main__': main()
